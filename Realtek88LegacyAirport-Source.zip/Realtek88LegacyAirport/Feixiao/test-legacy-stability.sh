#!/bin/zsh
set -u
IFACE="${1:-en1}"
AIRPORT="/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"
TS=$(date +%Y%m%d-%H%M%S)
OUT="legacy-stability-${TS}.log"
exec > >(tee -a "$OUT") 2>&1

echo "=== Realtek88LegacyAirport stability snapshot ==="
date
sw_vers
kextstat | grep -Ei 'HS80211|rtw88|legacyairport' || true
"$AIRPORT" -I || true
networksetup -getairportpower "$IFACE" || true

echo "\n=== default gateway ==="
GW=$(route -n get default 2>/dev/null | awk '/gateway:/{print $2; exit}')
echo "gateway=$GW"
if [[ -n "${GW:-}" ]]; then
  echo "\n=== 120-packet gateway ping ==="
  ping -c 120 -i 0.25 "$GW" || true
fi

echo "\n=== recent driver events ==="
/usr/bin/log show --last 10m --style syslog --predicate 'process == "kernel"' | \
  grep -Ei 'Realtek88LegacyAirport|rtw88: (associated|deauth|disassoc|TX ADDBA|RX ADDBA|connected chandef|Apple RSN key|failed|WARN)' || true

echo "\nSaved: $OUT"
