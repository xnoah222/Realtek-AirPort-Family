# Realtek88LegacyAirport.kext — 0.1.18-dev


## 0.1.18-dev — reconnect teardown + regulatory country

- Fully clears `vif->cfg.assoc`, AID and the hardware/rtwvif BSSID on disconnect instead of leaving the first association latched inside rtw88.
- AP-originated deauth/disassoc now removes the registered STA and BlockAck state too, so the following join starts clean.
- Invalidates the Legacy scan-cache throttle after disconnect/deauth, allowing one fresh RF scan when switching networks.
- Parses the selected AP's 802.11 Country IE and publishes the two-letter code through `APPLE80211_IOC_COUNTRY_CODE`; no country is invented when the AP does not advertise one.
- Keeps the 0.1.17 bounded BE TX queue thresholds; no RX reorder changes from the discarded 0.1.16 experiment.

## 0.1.17-dev — bounded BE TX queue latency

Based directly on the stable 0.1.15 RX/NAPI baseline; the 0.1.16 reorder experiment is intentionally not included.

- Keeps the 0.1.15 RX NAPI flush boundary unchanged.
- Changes only Legacy BE TX backpressure watermarks from 96/160 free descriptors to 224/240.
- With the 256-entry BE ring (255 usable), this limits normal outstanding BE descriptors to about 31 before stalling and resumes after draining to about 15.
- Goal: reduce queueing/bufferbloat under load without touching association, Apple RSN, RX reorder, scan throttling, or BlockAck/A-MPDU negotiation.
- This is deliberately a test build: compare idle and loaded gateway ping against 0.1.15 before keeping it.

## 0.1.15-dev — RX NAPI flush baseline

- TX ADDBA is no longer fired directly from the GTK/EAPOL completion callback. It starts on the first normal data packet after the controlled port is ready.
- Adds bounded TX ADDBA retries (after 32 unaggregated data frames, up to 4 attempts) with fresh dialog tokens.
- `SCAN_REQ_MULTIPLE` now uses the same 5-second deferred/coalesced cache completion as ordinary connected `SCAN_REQ`; 0.1.13 accidentally left this path synchronous.
- Keeps 0.1.13 peer-STA registry, management ACK semantics, RX BlockAck parsing, and all association/Apple-RSN fixes intact.

## 0.1.13-dev — HT/A-MPDU and connected-scan latency fix

- HT/VHT eligibility now depends on the pairwise cipher. A TKIP GTK no longer disables HT when the station negotiated CCMP pairwise.
- This allows the existing BlockAck code to negotiate TX/RX A-MPDU on mixed WPA2 networks.
- Connected cache-only scan completions are coalesced for 500 ms instead of being posted synchronously; this breaks the HS80211 SCAN_DONE request loop seen hundreds of times per minute.
- Association, Apple RSN, raw AP RSN caching, PTK/GTK installation, RX batching, and TX backpressure are unchanged from 0.1.11.


## 0.1.11-dev — Throughput and stability baseline

Association/WPA2 from 0.1.10 is unchanged. This build targets the data path:

- Adds TX backpressure to the IO80211 output queue using the BE-ring free-slot count.
  Frames are stalled/retried instead of silently falling into an rtw88 `-ENOSPC` path during sustained upload.
- Registers a legacy TX-resume callback fired after the IRQ bottom-half frees descriptors.
- Batches RX delivery: packets are queued during one Realtek IRQ burst and `flushInputQueue()` is called once at the end of the burst, rather than once per MSDU.
- Reorder-timeout delivery explicitly flushes the RX queue so the final packet of a burst cannot remain queued.
- Removes per-interrupt debug logging from the fallback interrupt wrapper.
- Keeps the 0.1.10 raw-AP-RSN fix, Apple RSN, scan throttle, guarded HS80211 link-state bridge, and passive AWDL VIF base unchanged.

This is deliberately a conservative performance build: no new channel-width, rate-mask, crypto, or AWDL-radio behavior is introduced until throughput/stability is measured.

## 0.1.10-dev — Preserve the AP's raw RSN IE for Apple RSN

- Fixes WPA2 4-way handshake failure on mixed TKIP+CCMP APs where HS80211 rejected EAPOL message 3 with `RSN IE does not match IE in beacon/probe response`.
- `APPLE80211_IOC_AP_IE_LIST` now returns the raw RSN IE captured from the selected AP's beacon/probe response.
- Keeps `_assocRsnIE` separate: it remains the station-selected RSN IE used in the association request.
- Matches AirportItlwm's split between association RSN override and BSS/authenticator RSN metadata.
- Keeps the guarded HS80211 link-state bridge and passive AWDL/VIF base from 0.1.9.


## 0.1.9-dev — HS80211 link-state bridge + Apple RSN association

- Restores the `IO80211Interface::setLinkState()` transition required by Apple RSN/EAPOL.
- Uses an AirportItlwm-style full-status recursion guard before calling into HS80211, so the callback into `setLinkStatus()` does not recurse.
- Keeps the 0.1.8 Apple-RSN association path and passive AWDL/VIF base.
- Adds `LEGACY_LINKSTATE_RET` / `LEGACY_LINKSTATE_UP` diagnostics.


- Legacy association now matches `useAppleRSNSupplicant()`: protected WPA2-PSK joins no longer require a 32-byte PMK in `apple80211_assoc_data.ad_key`; a valid 32-byte value is preserved as optional metadata when HS80211 supplies it. rtw88 performs 802.11 authentication/association, then Apple EAPOL/RSN supplies PTK/GTK through `CIPHER_KEY`.
- Pending joins now include the internal/external supplicant mode, avoiding accidental coalescing between different security paths.
- Adds passive HS80211 virtual-interface lifecycle hooks (`enableVirtualInterface`, `disableVirtualInterface`, `setVirtualHardwareAddress`, `apple80211VirtualRequest`) as the AWDL/P2P control-plane base. They delegate semantics to HS80211 and do **not** yet switch channels or enable the AWDL radio/data plane.
- Preserves the 0.1.7 non-recursive link-state fix, 0.1.6 VIF creation bridge, and 0.1.4 scan throttle.
- Scope of this dev build: open networks and WPA2-Personal/CCMP using the existing Apple-RSN backend. WPA Enterprise/WPA3 and full AWDL are not claimed yet.


## 0.1.7-dev HS80211 link-state recursion fix

- Fixes the Mojave kernel panic where `Realtek88LegacyAirport::setLinkStatus()` called `HS80211Interface::setLinkState()`, which immediately re-entered the controller `setLinkStatus()` callback until the kernel stack overflowed.
- Legacy now publishes controller link state once through `IO80211Controller::setLinkStatus()` and leaves interface link-state propagation to HS80211.
- Keeps the 0.1.6 HS80211 virtual-interface bridge and the legacy scan throttle.


## 0.1.6-dev HS80211 virtual-interface startup fix
- `APPLE80211_IOC_VIRTUAL_IF_CREATE`/`DELETE` are no longer hard-disabled in the Legacy dispatcher.
- On Mojave, the observed startup sequence reaches selector 94 (`VIRTUAL_IF_CREATE`); Legacy now asks HS80211 itself to attach a real family-owned `IO80211VirtualInterface` via `attachVirtualInterface()` instead of returning `kIOReturnUnsupported` or faking success.
- The Legacy frontend keeps only a non-owning VIF pointer/role for idempotent CREATE/DELETE handling. AWDL transport is still **not** claimed as functional.
- Added bounded boot diagnostics around the family attach call so a future stall can be localized to before/inside/after `attachVirtualInterface()`.

## 0.1.5-dev identity cleanup

- Runtime IOService class is `Realtek88LegacyAirport` on the Legacy target.
- Runtime interface class is `Realtek88LegacyAirportInterface`.
- Legacy logs use the `Realtek88LegacyAirport:` prefix instead of leaking the shared `AirportRTW88` implementation name.
- `APPLE80211_IOC_DRIVER_VERSION`, `CFBundleGetInfoString`, `CFBundleVersion`, and the KMOD version are synchronized to 0.1.18.
- Keeps the 0.1.4 Mojave scan-throttle/cache-completion changes.


Legacy AirPort frontend for the Feixiao/rtw88 backend. The target is macOS Mojave 10.14, Catalina 10.15 and Big Sur 11 using the High Sierra IO80211 stack supplied by `HS80211Family.kext`.

## Design

- Backend: existing rtw88 PCIe core and firmware loader.
- Frontend ABI: `__IO80211_TARGET=__MAC_10_13` because HS80211Family exposes the High Sierra IO80211 ABI.
- Deployment target: macOS 10.14.
- Bundle ID: `com.rtw88.legacyairport`.
- Current scope: infrastructure/STA Wi-Fi first. HS80211 owns a minimal AWDL/P2P virtual-interface control-plane base, but AWDL channel scheduling and data transport remain disabled until STA association/stability are proven.
- Supported personalities currently mirror AirPort_RTW88: RTL8822BE, RTL8822CE and RTL8821CE.

## Build on macOS

```sh
cd Feixiao
chmod +x build-legacy.sh
./build-legacy.sh
```

Output: `build-legacy/out/Realtek88LegacyAirport.kext`

`MacKernelSDK` and the sibling `rtw88-stable` tree must remain in their current locations. Xcode Command Line Tools are required.

## OpenCore load order

1. `HS80211Family.kext`
2. `Realtek88LegacyAirport.kext`

Recommended Kernel/Add range for both legacy components in this project: `MinKernel 18.0.0`, `MaxKernel 20.99.99` (Mojave through Big Sur). Do not inject this frontend together with `AirPort_RTW88.kext` for the same device.

`HS80211Family.kext` is not redistributed in this source package. The driver explicitly depends on its bundle identifier `com.apple.iokit.HS80211Family`; using a renamed kext whose internal CFBundleIdentifier is still `com.apple.iokit.IO80211Family` will not satisfy that dependency.

## First boot checks

```sh
kextstat | grep -Ei '80211|rtw88|realtek'
ioreg -l -w0 | grep -i -E 'AirportRTW88|Realtek88LegacyAirport|IO80211'
log show --last boot --predicate 'process == "kernel"' | grep -Ei 'RTW88|Realtek88LegacyAirport|AirPort_RTW88'
```

Verify in this order: kext attaches to the PCI device, Wi-Fi can be toggled on, scan results appear, open network association (if available), WPA2 association, traffic/DHCP, reconnect after disable/enable, then sleep/wake.

## Status

The legacy sources and all backend/frontend translation units have been compiled as x86_64 Mach-O objects against the 10.14 deployment target in the development environment. The environment cannot perform the final Apple kext link or runtime hardware testing, so this is intentionally marked **0.1.7-dev**, not a proven stable release.


## 0.1.4-dev fixes

- Corrected `OSBundleLibraries` from `com.apple.iokit.IO80211Family` to `com.apple.iokit.HS80211Family`.
- Legacy frontend now returns `true` from `useAppleRSNSupplicant()` so the compile-time `USE_APPLE_SUPPLICANT=1` setting and runtime IO80211 contract agree.
- Added the legacy `outputRaw80211Packet()` override used by the IO80211 controller ABI.
- Added a Legacy-specific `DriverBuild` property so logs cannot be confused with the Ventura build.

## First-boot diagnostics

After booting, run `./diagnose-legacy.sh` from this directory. It writes `legacy-diagnostic.txt` containing the loaded-kext list, PCI attachment, IORegistry properties and matching kernel log lines.


## 0.1.4-dev Mojave linker fix

Mojave (Darwin 18) does not export `_IOMallocZero`. The Legacy target now uses an internal zero-allocation helper implemented with `IOMalloc` and explicit byte zeroing. The modern AirPort_RTW88 target keeps using `IOMallocZero`; only `RTW88_LEGACY_AIRPORT` selects the compatibility path.


## 0.1.4-dev: legacy Apple80211 ioctl ABI

Mojave/HS80211 calls `apple80211Request()` with the 40-byte Apple80211 request
encoding (`SIOCGA80211=0xc02869c9`, `SIOCSA80211=0x802869c8`). The source SDK
used by the modern driver exposes the later 48-byte encodings instead. The
Legacy target now normalizes the old opcodes before dispatch so requests such
as CARD_CAPABILITIES (selector 12) reach their handlers instead of returning
`kIOReturnBadArgument`. The modern target is unchanged.


## 0.1.4-dev: Mojave scan-storm / UI-freeze mitigation

Mojave HS80211 can immediately submit another SCAN_REQ after SCAN_DONE. The RTL88 manual fallback scans every enabled channel and takes roughly 2.7 seconds on the tested RTL8822BE, which caused a continuous scan loop before CoreWLAN ever issued APPLE80211_IOC_ASSOCIATE. Legacy now performs one real RF scan to prime the backend BSS cache, then services repeated scan requests asynchronously from that cache (100 ms completion) until Wi-Fi is re-enabled. High-frequency SCAN_RESULT/CARD_CAPABILITIES debug logging and IORegistry diagnostic writes are also suppressed on Legacy. Modern AirPort_RTW88 behavior is unchanged.


### 0.1.13-dev stability / uplink A-MPDU
- Registers the associated peer STA with the mac80211 compatibility layer so upstream rtw88 `ieee80211_find_sta()` callers can configure A-MPDU factor, beacon filtering and peer-specific state.
- Unicast management/action frames now use normal ACK/retry semantics; `NO_ACK` is kept only for multicast/broadcast management frames.
- BlockAck RX matching accepts the AP in either transmitter (`addr2`) or BSSID (`addr3`) position and logs the action code for diagnosis.
- Connected cache scans are coalesced for 5 seconds instead of 500 ms to stop HS80211 from continuously polling the workloop while associated.
