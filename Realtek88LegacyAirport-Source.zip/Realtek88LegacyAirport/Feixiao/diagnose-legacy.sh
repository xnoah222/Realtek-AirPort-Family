#!/bin/zsh
set -u
OUT="${1:-legacy-diagnostic.txt}"
{
  echo "=== Realtek88LegacyAirport diagnostic ==="
  date
  sw_vers 2>/dev/null || true
  uname -a
  echo
  echo "=== Loaded kexts ==="
  if command -v kmutil >/dev/null 2>&1; then
    kmutil showloaded 2>&1 | grep -Ei 'HS80211|Realtek88|AirportRTW88|IO80211' || true
  else
    kextstat 2>&1 | grep -Ei 'HS80211|Realtek88|AirportRTW88|IO80211' || true
  fi
  echo
  echo "=== Kext dependency/preflight ==="
  if [[ -d build-legacy/out/Realtek88LegacyAirport.kext ]]; then
    kextutil -nt build-legacy/out/Realtek88LegacyAirport.kext 2>&1 || true
  else
    echo "build-legacy/out/Realtek88LegacyAirport.kext not found"
  fi
  echo
  echo "=== IORegistry controller / PCI ==="
  ioreg -l -w0 2>&1 | grep -Ei -C 4 'Realtek88LegacyAirport|AirportRTW88|10ec|B822|C822|C821|B821' || true
  echo
  echo "=== Kernel log ==="
  log show --last boot --style compact --predicate 'process == "kernel"' 2>/dev/null | \
    grep -Ei 'Realtek88LegacyAirport|AirportRTW88|rtw88|HS80211|IO80211' || true
} > "$OUT"
echo "Wrote $OUT"
