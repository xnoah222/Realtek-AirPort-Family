/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
#include <IOKit/80211/IO80211Controller.h>
#include <IOKit/80211/IO80211VirtualInterface.h>
#include <IOKit/80211/apple80211_ioctl.h>

#include "RTW88AWDLManager.hpp"
#include "RTW88IEEE80211.hpp"
#include <kern/clock.h>
#include <mach/mach_time.h>

namespace {
template <typename R> struct AWDLResult {
    R value{};
    template <typename F> void call(F &f) { value = f(); }
    R get() { return value; }
};
template <> struct AWDLResult<void> {
    template <typename F> void call(F &f) { f(); }
    void get() {}
};
// IOWorkLoop's gate is recursive. runAction also handles callers outside the
// workloop without reaching into protected APIs or introducing a second lock.
template <typename R, typename F>
R awdlGated(IOWorkLoop *loop, OSObject *owner, F fn)
{
    if (!loop) return fn();
    struct Task { F function; AWDLResult<R> result; } task{fn, {}};
    loop->runAction([](OSObject *, void *arg, void *, void *, void *) -> IOReturn {
        auto *task = static_cast<Task *>(arg);
        task->result.call(task->function);
        return kIOReturnSuccess;
    }, owner, &task);
    return task.result.get();
}
}

RTW88AWDLManager::~RTW88AWDLManager()
{
    reset();
}

bool RTW88AWDLManager::init(RTW88IEEE80211 *backend, IOWorkLoop *workLoop,
                              IOService *owner, IOTimerEventSource::Action action)
{
    if (!backend || !workLoop || !owner || !action)
        return false;
    _backend = backend;
    _workLoop = workLoop;
    _owner = owner;
    _timer = IOTimerEventSource::timerEventSource(owner, action);
    _txBuffer = (uint8_t *)IOMalloc(RTW88AWDL::MaxFrame);
    if (!_timer || !_txBuffer) return false;
    if (_workLoop->addEventSource(_timer) != kIOReturnSuccess) return false;
    _timerAttached = true;
    _syncEnabled = true;
    _p2pEnabled = false;
    _electionMetric = 0;
    _electionId = 0;
    _masterChannel = 0;
    _secondaryMasterChannel = 0;
    _presenceMode = 0;
    _syncState = 0;
    _actionFrameTxMode = 0;
    _minRate = 0;
    _deviceCapabilities = 0;
    memcpy(_bssid, RTW88AWDL::BSSID, sizeof(_bssid));
    _peerRegistrations = 0;
    publishStats();
    return true;
}

void RTW88AWDLManager::scheduleDiscovery()
{
    // One delayed bootstrap only; normal periodic scheduling still requires
    // an enabled interface and a validated Apple synchronization template.
    if (_timer && _timerAttached) _timer->setTimeoutMS(1000);
}

void RTW88AWDLManager::reset()
{
    return awdlGated<void>(_workLoop, _owner, [&]() -> void {
    if (_timer) {
        _timer->cancelTimeout();
        if (_timerAttached && _workLoop) _workLoop->removeEventSource(_timer);
        _timer->release(); _timer = nullptr; _timerAttached = false;
    }
    flushData();
    if (_airTemplate) { IOFree(_airTemplate, _airTemplateLength); _airTemplate = nullptr; }
    _airTemplateLength = 0;
    if (_txBuffer) { IOFree(_txBuffer, RTW88AWDL::MaxFrame); _txBuffer = nullptr; }
    _owner = nullptr;
    bzero(_peers, sizeof(_peers));
    _awdlInterface = nullptr;
    _p2pInterface = nullptr;
    _backend = nullptr;
    _workLoop = nullptr;
    _syncEnabled = true;
    _p2pEnabled = false;
    _electionMetric = 0;
    _electionId = 0;
    _masterChannel = 0;
    _secondaryMasterChannel = 0;
    _presenceMode = 0;
    _syncState = 0;
    _actionFrameTxMode = 0;
    _minRate = 0;
    _deviceCapabilities = 0;
    memcpy(_bssid, RTW88AWDL::BSSID, sizeof(_bssid));
    _peerRegistrations = 0;
    bzero(_syncChannelSequence, sizeof(_syncChannelSequence));
    _syncChannelSequenceLength = 0;
    _availabilityWindowLength = 0;
    _availabilityWindowPeriod = 0;
    _extensionLength = 0;
    _synchronizationFramePeriod = 0;
    _syncParamsValid = false;
    if (_syncTemplate) {
        IOFree(_syncTemplate, _syncTemplateLength);
        _syncTemplate = nullptr;
        _syncTemplateLength = 0;
    }
    });
}

void RTW88AWDLManager::setVirtualInterface(UInt role, IO80211VirtualInterface *interface)
{
    return awdlGated<void>(_workLoop, _owner, [&]() -> void {
    if (role == APPLE80211_VIF_AWDL) {
        _awdlInterface = interface;
        arm(1);
    }
    else if (role >= APPLE80211_VIF_P2P_DEVICE && role <= APPLE80211_VIF_P2P_GO)
        _p2pInterface = interface;
    });
}

void RTW88AWDLManager::clearVirtualInterface(IO80211VirtualInterface *interface)
{
    return awdlGated<void>(_workLoop, _owner, [&]() -> void {
    if (_awdlInterface == interface) {
        _awdlInterface = nullptr;
        if (_timer) _timer->cancelTimeout();
        flushData();
    }
    if (_p2pInterface == interface)
        _p2pInterface = nullptr;
    });
}

void RTW88AWDLManager::setBSSID(const uint8_t *bssid)
{
    if (bssid) memcpy(_bssid, bssid, sizeof(_bssid));
}

void RTW88AWDLManager::getBSSID(uint8_t *bssid) const
{
    if (bssid) memcpy(bssid, _bssid, sizeof(_bssid));
}

IOReturn RTW88AWDLManager::setSyncFrameTemplate(const void *payload, uint32_t length)
{
    return awdlGated<IOReturn>(_workLoop, _owner, [&]() -> IOReturn {
    RTW88AWDL::Action parsed;
    if (!RTW88AWDL::parseAction((const uint8_t *)payload, length, parsed)) {
        if (_owner) _owner->setProperty("AWDL_TEMPLATE_REJECTED_LENGTH", (uint64_t)length, 32);
        return kIOReturnBadArgument;
    }
    const uint32_t prefix = parsed.actionOffset ? 0 : 24;
    if (length + prefix > RTW88AWDL::MaxFrame) return kIOReturnNoSpace;
    if (!RTW88AWDL::unicast(_localAddress)) return kIOReturnNotReady;
    uint8_t *raw = (uint8_t *)IOMalloc(length);
    uint8_t *air = (uint8_t *)IOMalloc(length + prefix);
    if (!raw || !air) {
        if (raw) IOFree(raw, length);
        if (air) IOFree(air, length + prefix);
        return kIOReturnNoMemory;
    }
    memcpy(raw, payload, length);
    if (prefix) {
        bzero(air, 24); air[0] = 0xd0;
        memset(air + 4, 0xff, 6);
        memcpy(air + 16, RTW88AWDL::BSSID, 6);
    }
    memcpy(air + prefix, payload, length);
    memcpy(air + 10, _localAddress, 6);
    RTW88AWDL::Action normalized;
    RTW88AWDL::Clock clock;
    if (!RTW88AWDL::parseAction(air, length + prefix, normalized) ||
        !clock.set(normalized, nowUS())) {
        IOFree(raw, length); IOFree(air, length + prefix);
        return kIOReturnBadArgument;
    }
    if (_syncTemplate) IOFree(_syncTemplate, _syncTemplateLength);
    if (_airTemplate) IOFree(_airTemplate, _airTemplateLength);
    _syncTemplate = raw; _syncTemplateLength = length;
    _airTemplate = air; _airTemplateLength = length + prefix;
    _action = normalized; _clock = clock; _nextActionUS = 0;
    if (_owner) _owner->setProperty("AWDL_TEMPLATE_READY", kOSBooleanTrue);
    arm(1);
    return kIOReturnSuccess;
    });
}

IOReturn RTW88AWDLManager::copySyncFrameTemplate(void *payload, uint32_t *length) const
{
    return awdlGated<IOReturn>(_workLoop, _owner, [&]() -> IOReturn {
    if (!payload || !length)
        return kIOReturnBadArgument;
    if (!_syncTemplate || !_syncTemplateLength)
        return kIOReturnNotReady;

    /* Treat *length as the caller-provided capacity.  The old code copied the
     * whole saved template unconditionally, which could overflow an IO80211
     * buffer if a smaller payload was supplied on GET. */
    const uint32_t capacity = *length;
    *length = _syncTemplateLength;
    if (capacity < _syncTemplateLength)
        return kIOReturnNoSpace;

    memcpy(payload, _syncTemplate, _syncTemplateLength);
    return kIOReturnSuccess;
    });
}

void RTW88AWDLManager::notePeerTrafficRegistration(bool active)
{
    if (active)
        ++_peerRegistrations;
    else if (_peerRegistrations)
        --_peerRegistrations;
}

uint64_t RTW88AWDLManager::nowUS()
{
    uint64_t ns = 0;
    absolutetime_to_nanoseconds(mach_absolute_time(), &ns);
    return ns / 1000;
}

void RTW88AWDLManager::arm(uint32_t milliseconds)
{
    if (_timer && _syncEnabled && _awdlInterface && _airTemplate)
        _timer->setTimeoutMS(milliseconds);
}

void RTW88AWDLManager::setSyncEnabled(bool enabled)
{
    return awdlGated<void>(_workLoop, _owner, [&]() -> void {
    _syncEnabled = enabled;
    if (!enabled) {
        if (_timer) _timer->cancelTimeout();
        flushData();
    } else {
        _nextActionUS = 0;
        arm(1);
    }
    });
}

void RTW88AWDLManager::setLocalAddress(const uint8_t *mac)
{
    return awdlGated<void>(_workLoop, _owner, [&]() -> void {
    if (!mac || !RTW88AWDL::unicast(mac)) return;
    memcpy(_localAddress, mac, 6);
    if (_backend) _backend->setAWDLAddress(mac);
    if (_airTemplate) memcpy(_airTemplate + 10, mac, 6);
    });
}

void RTW88AWDLManager::flushData()
{
    for (auto &entry : _pending) {
        if (entry.packet) { mbuf_freem(entry.packet); ++_dataDropped; }
        entry.packet = nullptr; entry.queuedUS = 0;
    }
    _queueHead = _queueCount = 0;
}

bool RTW88AWDLManager::enqueueData(mbuf_t m)
{
    return awdlGated<bool>(_workLoop, _owner, [&]() -> bool {
    if (!m) return false;
    if (!_syncEnabled || !_awdlInterface || !_airTemplate || _queueCount == 128 ||
        mbuf_pkthdr_len(m) < 14 || mbuf_pkthdr_len(m) > 4096) {
        mbuf_freem(m); ++_dataDropped;
        return false;
    }
    Pending &entry = _pending[(_queueHead + _queueCount) % 128];
    entry.packet = m; entry.queuedUS = nowUS();
    ++_queueCount;
    arm(1);
    return true;
    });
}

void RTW88AWDLManager::observeAction(const uint8_t *frame, uint32_t length)
{
    RTW88AWDL::Action action;
    if (!RTW88AWDL::parseAction(frame, length, action) || action.actionOffset != 24) return;
    return awdlGated<void>(_workLoop, _owner, [&]() -> void {
    if (!_awdlInterface || !memcmp(frame + 10, _localAddress, 6)) return;
    const uint64_t now = nowUS();
    RTW88AWDL::Clock clock;
    if (!clock.set(action, now)) return;
    Peer *peer = nullptr, *oldest = &_peers[0];
    for (auto &p : _peers) {
        if (!memcmp(p.mac, frame + 10, 6)) { peer = &p; break; }
        if (p.seenUS < oldest->seenUS) oldest = &p;
    }
    if (!peer) peer = oldest;
    memcpy(peer->mac, frame + 10, 6);
    peer->clock = clock; peer->sequence = action.sequence; peer->seenUS = now;
    ++_actionRx;
    // IO80211 owns election. Only follow the master named in its template,
    // never let an unrelated nearby peer reset our clock.
    if (_airTemplate && !memcmp(_action.master, frame + 10, 6) &&
        action.awPeriod == _action.awPeriod && action.presence == _action.presence) {
        _clock = clock;
        ++_syncUpdates;
    }
    });
}

void RTW88AWDLManager::drainData(uint64_t now, const RTW88AWDL::Window &window)
{
    const unsigned count = _queueCount;
    unsigned submitted = 0;
    for (unsigned i = 0; i < count; ++i) {
        Pending entry = _pending[_queueHead];
        _pending[_queueHead] = {};
        _queueHead = (_queueHead + 1) % 128;
        --_queueCount;
        uint8_t destination[6] = {};
        bool expired = now < entry.queuedUS || now - entry.queuedUS > 2000000;
        if (expired || mbuf_copydata(entry.packet, 0, 6, destination) != 0) {
            mbuf_freem(entry.packet); ++_dataDropped;
            continue;
        }
        bool ready = false;
        if (destination[0] & 1) {
            ready = RTW88AWDL::multicastWindow(window);
        } else {
            for (const auto &peer : _peers) {
                if (!peer.seenUS || now < peer.seenUS || now - peer.seenUS > 3000000 ||
                    memcmp(destination, peer.mac, 6)) continue;
                const auto pw = RTW88AWDL::window(peer.clock, peer.sequence, now);
                ready = pw.channel == window.channel && RTW88AWDL::insideGuard(pw);
                break;
            }
        }
        if (ready && submitted < 16 && _backend->canTransmitAWDL()) {
            if (_backend->txAWDLDataFrame(entry.packet)) ++_dataTx;
            else ++_dataDropped;
            ++submitted;
        } else {
            _pending[(_queueHead + _queueCount) % 128] = entry;
            ++_queueCount;
        }
    }
}

void RTW88AWDLManager::publishStats()
{
    if (!_owner) return;
    _owner->setProperty("AWDL_SCHEDULER_VERSION", "v30-template-clock");
    _owner->setProperty("AWDL_ACTION_TX", (uint64_t)_actionTx, 32);
    _owner->setProperty("AWDL_ACTION_RX", (uint64_t)_actionRx, 32);
    _owner->setProperty("AWDL_SYNC_UPDATES", (uint64_t)_syncUpdates, 32);
    _owner->setProperty("AWDL_DATA_TX", (uint64_t)_dataTx, 32);
    _owner->setProperty("AWDL_DATA_DROPPED", (uint64_t)_dataDropped, 32);
    _owner->setProperty("AWDL_QUEUE_DEPTH", (uint64_t)_queueCount, 32);
    _owner->setProperty("AWDL_BLOCKED_WINDOWS", (uint64_t)_blockedWindows, 32);
    _owner->setProperty("AWDL_CHANNEL_RESULT", (uint64_t)(uint32_t)_lastChannelResult, 32);
}

bool RTW88AWDLManager::tick()
{
    return awdlGated<bool>(_workLoop, _owner, [&]() -> bool {
    if (!_backend || !_syncEnabled || !_awdlInterface || !_airTemplate || !_txBuffer) return false;
    uint64_t now = nowUS();
    auto window = RTW88AWDL::window(_clock, _action.sequence, now);
    _lastChannelResult = window.channel ? _backend->setAWDLChannel(window.channel) : kIOReturnNotReady;
    // RF calibration may have crossed a window boundary. Never send using
    // the timestamp or channel decision made before the retune completed.
    now = nowUS();
    auto after = RTW88AWDL::window(_clock, _action.sequence, now);
    bool ready = _lastChannelResult == kIOReturnSuccess && after.slot == window.slot &&
        RTW88AWDL::insideGuard(after) && _backend->canTransmitAWDL();
    if (ready) {
        if (now >= _nextActionUS) {
            memcpy(_txBuffer, _airTemplate, _airTemplateLength);
            RTW88AWDL::stamp(_txBuffer, _action, after, now, _actionSequence++);
            if (_backend->txRawManagementFrame(_txBuffer, _airTemplateLength)) ++_actionTx;
            _nextActionUS = now + uint64_t(_action.afPeriod) * 1024;
        }
        drainData(now, after);
    } else {
        ++_blockedWindows;
        // Expire old packets even while STA owns the radio.
        for (auto &entry : _pending) {
            if (entry.packet && now > entry.queuedUS + 2000000) {
                // Keep queue invariants: drainData expires without transmitting
                // with a zero channel and a non-multicast slot.
                RTW88AWDL::Window unavailable; unavailable.slot = 1;
                drainData(now, unavailable);
                break;
            }
        }
    }
    if (now >= _lastStatsUS + 1000000) { publishStats(); _lastStatsUS = now; }
    // Back off while STA/scanning owns a different channel.
    arm(_lastChannelResult == kIOReturnSuccess ? 2 : 16);
    return ready;
    });
}
