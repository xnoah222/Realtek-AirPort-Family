/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause
 * Build-target identity for the shared AirPort frontend.
 *
 * AirPort_RTW88 and Realtek88LegacyAirport intentionally share the same
 * implementation, but they must not expose the same runtime IOService class
 * name or driver/version strings.  Keep the source reuse internal.
 */
#pragma once

#ifdef RTW88_LEGACY_AIRPORT
#define AirportRTW88 Realtek88LegacyAirport
#define AirportRTW88Interface Realtek88LegacyAirportInterface
#define RTW88_DRIVER_LOG_NAME "Realtek88LegacyAirport"
#define RTW88_DRIVER_VERSION_STRING "Realtek88LegacyAirport 1.0.0"
#else
#define RTW88_DRIVER_LOG_NAME "AirPort_RTW88"
#define RTW88_DRIVER_VERSION_STRING "AirPort_RTW88 1.0.3"
#endif
