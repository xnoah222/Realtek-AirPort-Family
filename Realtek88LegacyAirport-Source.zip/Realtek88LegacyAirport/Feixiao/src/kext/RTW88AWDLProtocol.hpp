/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* Wire-format facts: AWDL action header and TLVs, independently implemented.
 * References and supported subset are documented in V22_AWDL.md.
 * This header deliberately has no IOKit dependency so production parsing and
 * time arithmetic can run under ASan/UBSan with malformed radio frames. */
namespace RTW88AWDL {
constexpr uint8_t BSSID[6] = {0x00,0x25,0x00,0xff,0x94,0x73};
constexpr unsigned MaxFrame = 4096;
inline uint16_t le16(const uint8_t *p) { return uint16_t(p[0]) | (uint16_t(p[1]) << 8); }
inline void put16(uint8_t *p, uint16_t v) { p[0]=uint8_t(v); p[1]=uint8_t(v>>8); }
inline void put32(uint8_t *p, uint32_t v) { for (unsigned i=0;i<4;++i) p[i]=uint8_t(v>>(8*i)); }
inline bool unicast(const uint8_t *p) {
    uint8_t any=0; for (unsigned i=0;i<6;++i) any|=p[i];
    return any && !(p[0]&1);
}
struct Sequence {
    uint8_t channel[16] = {};
    uint8_t count = 0, stride = 0;
};
inline bool parseSequence(const uint8_t *p, size_t n, Sequence &out) {
    if (!p || n<6 || p[0]!=15 || p[2]!=0 || p[3]>15) return false;
    const unsigned width=p[1]==0 ? 1 : (p[1]==1 || p[1]==3 ? 2 : 0);
    if (!width || n<6+16*width) return false;
    // 0xffff means no fill beyond the sequence; support the common full list.
    if (le16(p+4)!=0xffff) return false;
    Sequence value; value.count=16; value.stride=uint8_t(p[3]+1);
    for (unsigned i=0;i<16;++i) {
        uint8_t ch=p[6+i*width+(p[1]==1 ? 1 : 0)];
        if (ch>196) return false; // 0 explicitly means unavailable.
        value.channel[i]=ch;
    }
    out=value;
    return true;
}
struct Action {
    uint16_t actionOffset=0, syncOffset=0;
    uint16_t awPeriod=0, afPeriod=0, countdown=0, awCounter=0, commonLength=0;
    uint8_t presence=0, master[6]={};
    Sequence sequence;
};
inline bool actionHeader(const uint8_t *p, size_t n) {
    return p && n>=16 && p[0]==127 && p[1]==0 && p[2]==0x17 &&
        p[3]==0xf2 && p[4]==8 && p[5]==0x10 && (p[6]==0 || p[6]==3);
}
inline bool parseAction(const uint8_t *p, size_t n, Action &out) {
    if (!p || n>MaxFrame) return false;
    Action a;
    if (!actionHeader(p,n)) {
        if (n<40 || p[0]!=0xd0 || (p[1]&0xc7) ||
            memcmp(p+16,BSSID,6) || !unicast(p+10) || !actionHeader(p+24,n-24)) return false;
        a.actionOffset=24;
    }
    bool haveSync=false, haveSequence=false;
    Sequence embedded;
    size_t pos=a.actionOffset+16;
    while (pos<n) {
        if (n-pos<3) return false;
        const unsigned type=p[pos], len=le16(p+pos+1);
        pos+=3;
        if (len>n-pos) return false;
        const uint8_t *v=p+pos;
        if (type==4) {
            if (haveSync || len<33) return false;
            haveSync=true; a.syncOffset=uint16_t(pos);
            a.countdown=le16(v+1); a.awPeriod=le16(v+5); a.afPeriod=le16(v+7);
            a.commonLength=le16(v+13); a.presence=v[27]; a.awCounter=le16(v+29);
            memcpy(a.master,v+21,6);
            if (!a.awPeriod || a.awPeriod>1024 || !a.afPeriod || a.afPeriod>4096 ||
                !a.presence || a.presence>16 || (a.presence&(a.presence-1)) ||
                a.countdown>uint32_t(a.awPeriod)*a.presence ||
                a.commonLength>a.awPeriod*a.presence || !unicast(a.master)) return false;
            if (len>33 && !parseSequence(v+33,len-33,embedded)) return false;
        } else if (type==18) {
            if (haveSequence || !parseSequence(v,len,a.sequence)) return false;
            haveSequence=true;
        }
        pos+=len;
    }
    if (!haveSync) return false;
    if (!haveSequence) a.sequence=embedded;
    if (!a.sequence.count || a.sequence.stride!=a.presence) return false;
    out=a;
    return true;
}
struct Clock {
    uint64_t epochUS=0;
    uint16_t epochAW=0, periodTU=0;
    uint8_t presence=0;
    bool set(const Action &a, uint64_t now) {
        const uint64_t elapsed=(uint64_t(a.awPeriod)*a.presence-a.countdown)*1024;
        if (now<elapsed) return false;
        epochUS=now-elapsed;
        epochAW=uint16_t(a.awCounter-(a.awCounter%a.presence));
        periodTU=a.awPeriod; presence=a.presence;
        return true;
    }
};
struct Window {
    uint16_t aw=0, remainingTU=0;
    uint8_t slot=0, channel=0;
    uint64_t elapsedUS=0, remainingUS=0;
};
inline Window window(const Clock &clock, const Sequence &seq, uint64_t now) {
    Window w;
    if (!clock.periodTU || !clock.presence || !seq.count || !seq.stride || now<clock.epochUS) return w;
    const uint64_t periodUS=uint64_t(clock.periodTU)*1024;
    const uint64_t eawUS=periodUS*clock.presence;
    const uint64_t elapsed=now-clock.epochUS;
    w.aw=uint16_t(clock.epochAW+elapsed/periodUS);
    w.slot=uint8_t((w.aw/seq.stride)%seq.count);
    w.channel=seq.channel[w.slot];
    w.elapsedUS=elapsed%eawUS; w.remainingUS=eawUS-w.elapsedUS;
    w.remainingTU=uint16_t((w.remainingUS+1023)/1024);
    return w;
}
inline bool insideGuard(const Window &w) {
    return w.channel && w.elapsedUS>=3*1024 && w.remainingUS>3*1024;
}
inline bool multicastWindow(const Window &w) { return w.slot==0 || w.slot==10; }
inline void stamp(uint8_t *frame, const Action &a, const Window &w, uint64_t now, uint16_t sequence) {
    uint8_t *hdr=frame+a.actionOffset;
    put32(hdr+8,uint32_t(now)); put32(hdr+12,uint32_t(now));
    uint8_t *sync=frame+a.syncOffset;
    sync[0]=w.channel;
    put16(sync+1,w.remainingTU); put16(sync+29,w.aw); put16(sync+31,w.aw);
    const uint64_t commonUS=uint64_t(a.commonLength)*1024;
    put16(sync+15,uint16_t(w.elapsedUS<commonUS ? (commonUS-w.elapsedUS)/1024 : 0));
    if (a.actionOffset==24) put16(frame+22,uint16_t((sequence&4095)<<4));
}
} // namespace RTW88AWDL
