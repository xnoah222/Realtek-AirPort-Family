/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause
 * Allocation helpers shared by the macOS frontend/firmware loader.
 *
 * Mojave's XNU does not export IOMallocZero.  Keep the modern path unchanged,
 * but make the Legacy Airport target use IOMalloc plus an explicit zero fill
 * so no _IOMallocZero import is emitted into the Mojave-compatible kext.
 */
#ifndef _RTW88_ALLOC_H
#define _RTW88_ALLOC_H

#include <stddef.h>
#include <stdint.h>
#include <IOKit/IOLib.h>

static inline void *rtw88_legacy_iomalloc_zero(size_t size)
{
    void *mem = IOMalloc(size);
    if (!mem)
        return NULL;

    /* Volatile byte stores deliberately avoid the compiler folding this into
     * a call to a newer zero-allocation helper.  This keeps the Legacy target
     * dependent only on IOMalloc, which is available on Mojave. */
    volatile uint8_t *p = (volatile uint8_t *)mem;
    for (size_t i = 0; i < size; ++i)
        p[i] = 0;
    return mem;
}

#ifdef RTW88_LEGACY_AIRPORT
#define RTW88_IOMALLOC_ZERO(sz) rtw88_legacy_iomalloc_zero((sz))
#else
#define RTW88_IOMALLOC_ZERO(sz) IOMallocZero((sz))
#endif

#endif /* _RTW88_ALLOC_H */
