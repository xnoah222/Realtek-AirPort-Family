#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
make legacy-clean
make legacy-airport
