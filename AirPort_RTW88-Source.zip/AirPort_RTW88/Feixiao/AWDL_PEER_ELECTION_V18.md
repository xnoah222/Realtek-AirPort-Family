# AirDrop: comparación con OWL/OpenAWDL y AirportItlwm — v18

## Evidencia de este equipo

v17 estaba cargada. La captura mostraba 432 paquetes de datos recibidos, 229 transmitidos, 163 unicast confirmados, 2 sin ACK y un vecino válido. Había 136 anuncios rechazados; la muestra guardada indicaba `master-mismatch`. También había 38 paquetes caducados y 2974 decisiones de aplazar transmisión por ausencia de un vecino válido (no son 2974 paquetes distintos).

En el anuncio conservado por el driver, el emisor y la dirección de maestro del TLV de sincronización eran A, mientras que elección v2 publicaba B como maestro y padre de sincronización. El MIF incluía versión, clase de dispositivo y secuencia de canales válidas. v17 lo descartaba completo antes de actualizar al vecino A. No se ha atribuido una MAC concreta al iPhone de tu hermana.

La misma muestra, con MACs anonimizadas, queda en `tests/fixtures/awdl_mif_election_v2.hex`. Reproducirla contra el parser archivado de v17 devuelve `accepted=0 reason=master-mismatch`.

## Comparación del código

| Área | Referencia consultada | AirPort_RTW88 y decisión |
|---|---|---|
| Sincronización / elección | OWL interpreta el reloj desde sincronización y la elección v2 desde su TLV propio; no rechaza el anuncio por desigualdad entre esas direcciones. | v17 imponía igualdad. v18 conserva la dirección de sincronización por separado y usa el maestro de elección v2 para la elección. |
| Promoción de vecino | OWL requiere MIF, versión y clase de dispositivo. | El driver ya aplica esa condición. Se conserva; no se inventan vecinos desde Bluetooth. |
| Publicación y selección | OWL distingue dirección del vecino, padre de sincronización y maestro superior. | Se comprueba que un MIF con A/B diferentes publica al emisor A y permite enviarle paquetes, sin confundirlo con B. |
| Ventanas multicast | OWL utiliza ventanas multicast específicas y comprueba coincidencia de canal para unicast. | Se conserva la planificación de v16/v17; esta revisión no cambia canales ni guardas. |
| Interfaz virtual | AirportItlwm oficial crea/activa la VIF y comunica el estado de enlace. | Esa integración sirve como referencia de ciclo de vida. |
| Salida AWDL | En el `master` oficial revisado, `outputActionFrame` y `bpfOutput80211Radio` liberan las tramas; la salida dentro de `requestPacketTx` está comentada. | No es una implementación completa de transporte AWDL que se pueda copiar para garantizar AirDrop. Se mantiene el transporte Realtek propio. |

Referencias primarias consultadas el 4 de octubre de 2026:

- [OWL: parser RX y elección v2](https://github.com/seemoo-lab/owl/blob/master/src/rx.c).
- [OWL: elección](https://github.com/seemoo-lab/owl/blob/master/src/election.c).
- [OWL: promoción de vecinos](https://github.com/seemoo-lab/owl/blob/master/src/peers.c).
- [OWL: planificación](https://github.com/seemoo-lab/owl/blob/master/src/schedule.c).
- [AirportItlwm oficial: interfaz virtual y salida](https://github.com/OpenIntelWireless/itlwm/blob/master/AirportItlwm/AirportItlwm.cpp).

Se tomó OWL de seemoo-lab como referencia pública OpenAWDL utilizada por este proyecto. La conclusión sobre AirportItlwm corresponde a la rama oficial examinada, no a todos sus forks. No se incorporó código copiado de esas implementaciones.

## Cambios de v18

- Elimina el rechazo por igualdad obligatoria entre maestro de sincronización y maestro de elección v2.
- Conserva `syncMaster` para inspección y utiliza elección v2 como fuente del maestro elegido. Sin ese TLV, conserva el comportamiento anterior.
- Mantiene las comprobaciones de longitud, duplicados, MAC unicast, profundidad de árbol y estructura de canales.
- Añade `AWDL_ELECTION_SYNC_MASTER_DIFFERENCES`, contador de anuncios aceptados con esa diferencia, y `AWDL_VALID_PEER_MACS`, lista concatenada de MACs de los vecinos válidos actuales.
- Corrige el diagnóstico Bonjour para consultar explícitamente AWDL mediante `-includeAWDL -i awdl0`.

## Pruebas

La prueba nueva reproduce el MIF real anonimizado, variantes malformadas, cambio de orden de TLVs y ausencia de elección v2. Después ejecuta el gestor de producción con dos vecinos y verifica publicación, envío unicast hacia ambos y ausencia de aplazamientos por vecino desconocido.

Se compiló el kext x86_64. Se ejecutó la suite con UBSan; los resultados completos están en `PRUEBAS-AWDL-v18.md`. ASan sigue sin poder ejecutarse en este host. Estas pruebas no sustituyen un envío real de archivos.

```sh
RTW88_TEST_SANITIZERS=undefined python3 tests/test_v212_awdl_election_capture.py
make -j4 airport
```

## Comprobación de AirDrop

Sustituye v17 por el kext v18 en la misma entrada de EFI, conserva una copia del anterior y reinicia. Esta sesión no modifica EFI ni carga el nuevo kext. Confirma:

```sh
ioreg -r -c AirportRTW88 -l | grep DriverBuild
```

Debe aparecer `2.0.1-awdl-peer-election-v18`. Prueba cada iPhone por separado como receptor con «Todos durante 10 minutos», y luego prueba el envío en sentido inverso hacia la Mac. No abras simultáneamente una hoja de envío en el receptor como única prueba de recepción.

Ejecuta `diagnostico-awdl-v18.command` durante la prueba. Comprueba si aumenta `AWDL_ELECTION_SYNC_MASTER_DIFFERENCES`, si ambos vecinos permanecen en `AWDL_VALID_PEER_MACS` y si dejan de acumularse aplazamientos `AWDL_DATA_DEFER_NO_PEER`.

Si sigue fallando, se necesita comprobar el intercambio Bonjour/TCP real. El sandbox de esta sesión impide abrir BPF, leer el registro unificado y consultar directamente mDNSResponder; esos errores no demuestran que Bonjour esté detenido. Desde Terminal, una captura de metadatos puede hacerse con:

```sh
sudo tcpdump -i awdl0 -n -vv 'ip6 and (udp port 5353 or tcp)'
```

Detén la captura con Ctrl-C tras reproducir el intento. No cambia ajustes ni instala componentes.

**AirDrop todavía no está validado de extremo a extremo con v18.** Hay un rechazo reproducido y corregido; no se afirma que sea el único problema. Continuity Camera queda fuera del objetivo solicitado. Se conservan RTL8822BE, RTL8822CE y RTL8821CE y las dependencias IO80211FamilyLegacy del proyecto.
