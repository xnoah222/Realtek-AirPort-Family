# AWDL TX pacing v8

This revision keeps the v7 ND6ALT/bootstrap path intact and changes only the
AWDL link-layer transmit queue policy.

## Why

The v7 packet trace proved that IPv6 host routes and ND6ALT neighbors work and
that remote Apple peers sometimes return TCP SYN-ACKs on awdl0.  However the
final ACK and the TLS/ASK payload were repeatedly lost.  The old scheduler could
submit up to 16 frames in one availability-window callback even though rtw88 PCI
TX is asynchronous and direct AWDL is intentionally pinned to 6 Mbps.  Frames
could therefore remain in the DMA ring when the single PHY returned to the STA
channel.

## Policy

* submit at most one AWDL data frame per scheduler tick;
* retain the 4 ms connected scheduler resolution;
* expire queued data after 1.2 seconds rather than 2-3 seconds so TCP
  retransmissions do not accumulate stale link-layer copies;
* do not change the radio, PCI, normal Wi-Fi queues, ND6ALT, peer lifecycle,
  parser, or channel-sequence logic.

New telemetry: `AWDL_DATA_TX_PACE_LIMIT`, `AWDL_DATA_TX_PACED_DEFERS`, and
`AWDL_DATA_QUEUE_MAX_AGE_US`.
