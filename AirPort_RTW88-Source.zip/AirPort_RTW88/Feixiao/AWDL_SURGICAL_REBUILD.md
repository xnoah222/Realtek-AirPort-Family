# AirPort_RTW88 2.0.1 — stable-core AWDL surgical rebuild

This branch starts from the known-good Realtek AirPort Family AirPort_RTW88 source. The objective is deliberately narrow: improve AWDL without changing the core Wi-Fi path that already works on RTL8822BE/RTL8822CE/RTL8821CE.

## Ownership rule

`en0` owns the physical RTL88 radio lifecycle. AWDL is a secondary client.

AWDL does not own PCI setup, interrupts, firmware start/stop, the primary rtw88 VIF, infrastructure association, normal scanning, or global power on/off. The AWDL scheduler starts only after the primary IO80211 enable path succeeds and is suspended before `en0` is disabled.

Because RTL8822BE is a single-PHY device, infrastructure and AWDL share the radio by short channel time slices. Every AWDL off-channel visit has a restoration path back to the infrastructure channel.

## One hardware VIF

`awdl0` remains an `IO80211P2PInterface` in macOS, but there is no second rtw88 station VIF. Raw AWDL management/data TX uses the already active primary rtw88 VIF as the hardware context. This avoids the multi-VIF/port/MAC-ID changes that destabilized the experimental branch.

## Outbound AWDL data

Physical tests showed real IPv6/Bonjour traffic on BSD `awdl0` while the private `IO80211VirtualInterface::dequeueOutputPacketsWithServiceClass()` path returned no packets.

The primary egress path in this rebuild is therefore an **interface filter attached only to `awdl0`** using the kernel interface-filter KPI. The filter sees a fully formed outbound L2 packet, duplicates it, finalizes pending checksums on the duplicate, and enqueues that duplicate into `RTW88AWDLManager`. The original packet and its BSD/IO80211 ownership are untouched.

If the interface-filter KPI cannot be attached, the old private dequeue path remains as a fallback. Failure of the AWDL data path is non-fatal to `en0`.

## Inbound AWDL data

The rtw88 RX path already decapsulates the AWDL 802.11 + LLC/SNAP envelope back to Ethernet. Instead of passing that Ethernet packet to `IO80211P2PInterface::inputPacket()` with guessed private packet-info storage, this branch uses the published `awdl0` ifnet directly and submits the Ethernet mbuf through the networking KPI.

## Peer ownership

AWDL action frames are still forwarded to the IO80211 AWDL virtual interface so Apple's peer manager can consume them. The driver no longer calls private `postPeerPresence`, `postPeerPresenceIPv6`, or `postPeerAbsence` virtual methods directly.

The internal parser still tracks MIF/Version/synchronization/election state for radio scheduling and telemetry.

## Scheduler changes retained

The newer scheduler work retained here includes:

- Apple sync-channel sequence parsing when supplied by IO80211.
- Native fallback social discovery on channel 6 plus supported 44/149 channels.
- Respect for explicit channel 44/149 hints instead of always preferring 149.
- Validated peer state before unicast data transmission.
- Multicast rendezvous with recently observed peers.
- Infrastructure-channel restoration when a common AWDL window ends or a channel transition fails.
- Bounded IORegistry telemetry rather than per-packet console spam.

## What was intentionally not changed

Relative to the stable source, this rebuild does not modify:

- `rtw88-stable/`
- `src/compat/`
- PCI/IRQ setup (`RTW88PCIDevice`)
- firmware/core start-stop
- normal scan and association implementation
- normal infrastructure TX/RX
- the Makefile or SDK headers

The only small `RTW88IEEE80211` changes are AWDL-specific radio helpers and AWDL-only channel/TX safeguards.

## Validation boundary

This source passes cross-target C++ syntax/object compilation in the development environment and avoids the derived `IO80211P2PInterface` subclass that caused a large private-vtable symbol dependency explosion in the prior experiment.

A full macOS kext link and real AWDL interoperability still require hardware testing on macOS. Do not claim full AirDrop support until bidirectional data counters and an actual transfer confirm it.


## Peer publication v2
Runtime testing showed the protocol parser observing three valid peers while IO80211 peer publication stayed at zero. The stable Realtek-AirPort-Family baseline's validated/throttled `postPeerPresence`/`postPeerPresenceIPv6` lifecycle is therefore restored. Return values remain intentionally opaque and are not used to drive radio state. Stale published peers receive `postPeerAbsence`.
