# AWDL TX report pipeline audit v13

This diagnostic revision keeps the v11/v12 AWDL radio, scheduler, RX, TSF,
ND6ALT and normal infrastructure Wi-Fi behavior unchanged. It instruments the
native rtw88 firmware TX-report pipeline so a missing AWDL completion can be
localized without interpreting a report timeout as an 802.11 NOACK.

Telemetry:

- `RTW88_TXR_DESCRIPTOR_ENABLED`: packets for which rtw88 set SPE_RPT.
- `RTW88_TXR_PCI_ENQUEUED`: requested packets moved from the PCI ring into the
  firmware-report wait queue after DMA completion.
- `RTW88_TXR_WAIT_QUEUE_DEPTH`: current report wait queue.
- `RTW88_TXR_C2H_SEEN`: CCX TX-report C2H events received from firmware.
- `RTW88_TXR_C2H_MATCHED` / `UNMATCHED`: sequence-number match result.
- `RTW88_TXR_PURGED_TIMEOUT`: packets purged after the upstream 500 ms timeout.
- last request/report sequence/status plus report-engine register snapshots.

Interpretation:

1. descriptor == PCI enqueued, C2H == 0, purged > 0: firmware did not return a
   CCX report for these frames.
2. C2H > 0, matched == 0, unmatched > 0: report sequence/format mismatch.
3. matched > 0: the v12 ACK/NOACK counters are authoritative.
