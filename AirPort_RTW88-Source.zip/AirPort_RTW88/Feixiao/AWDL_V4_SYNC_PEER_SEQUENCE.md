# AWDL v4 — sync-peer channel-sequence rendezvous

This revision keeps the stable Realtek-AirPort-Family Wi-Fi core unchanged.

The native AWDL fallback previously synchronized its clock to an elected Apple peer but kept tuning the RTL PHY using the bootstrap social-only 6/44/149 sequence. Real Apple peers can advertise established availability windows on other supported channels (for example 100). That leaves control/discovery alive while the data plane rarely or never overlaps.

v4 changes only RTW88AWDLManager policy:

- social-channel bootstrap remains unchanged before a sync peer is selected;
- once a native-fallback sync peer is elected, validate and adopt that peer's complete 16-entry sequence;
- use the same adopted sequence for radio scheduling and native MIF/PSF advertisement;
- revert to the local discovery sequence when the sync peer expires;
- never adopt a sequence containing an unsupported concrete channel;
- IO80211-provided schedules are untouched;
- PCI, firmware, interrupt, scan, association, power-management and normal en0 datapaths are untouched.

Telemetry: `AWDL_SYNC_PEER_SEQUENCE_ACTIVE`, `AWDL_SYNC_PEER_SEQUENCE_ADOPTIONS`, `AWDL_SYNC_PEER_MAC`, `AWDL_SYNC_PEER_SEQUENCE`, `AWDL_SCHEDULER_CHANNEL`, `AWDL_SCHEDULER_SLOT`.
