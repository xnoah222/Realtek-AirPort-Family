# Auditoría integrada de AWDL y AirDrop — v19

**Estado: código revisado y kext compilado; AirDrop físico aún no validado.** Esta revisión agrupa correcciones entre protocolo, planificación y salida de red. No se considera terminado el soporte AirDrop hasta descubrir ambos dispositivos y transferir archivos en ambos sentidos.

El equipo seguía cargando `2.0.1-awdl-bsd-input-v17` durante esta auditoría. La nueva lectura mostró 1295 acciones recibidas, 136 paquetes de datos recibidos y 0 vecinos válidos en ese instante. No identifica cuál teléfono emitió cada trama ni demuestra un fallo de Bluetooth. EFI y el kext cargado no fueron modificados.

## Referencias y alcance

Se contrastó con [OWL de seemoo-lab](https://github.com/seemoo-lab/owl), la implementación pública OpenAWDL empleada como referencia del proyecto, y con [AirportItlwm oficial](https://github.com/OpenIntelWireless/itlwm/blob/master/AirportItlwm/AirportItlwm.cpp), consultados el 4 de octubre de 2026. No se presume que todos los forks sean iguales. La implementación se escribió sobre este driver; no se incorporó código copiado de esos repositorios.

AirportItlwm sirve para revisar creación/activación de interfaces y puntos de entrada de IO80211. En la versión oficial examinada, varias rutas de salida AWDL liberan los paquetes o tienen la transmisión comentada. Por tanto, no proporciona un transporte completo que podamos copiar y dar por funcional.

## Recorrido revisado

| Tramo | Resultado de la revisión y cobertura |
|---|---|
| Acción PSF/MIF y TLVs | Se conservan límites, control de duplicados y validación de MAC. El MIF real anonimizado de v18 sigue siendo una regresión ejecutable; maestro de sincronización y maestro de elección pueden diferir. |
| Codificación de canales | Contrastadas simple, legacy y opclass: legacy lleva el canal en el segundo byte. No se cambia esa lectura. Secuencias admitidas: 16 entradas, sin duplicación, relleno 0xffff. Otros formatos siguen rechazados explícitamente. |
| Reloj y contador AW | Se añaden validaciones antes de divisiones/módulos y límites para índices. La prueba contempla campos inválidos. Se mantiene la normalización al inicio del EAW. |
| Elección | Se reevalúan todos los vecinos válidos, frente a la candidatura local: contador, métrica, altura y MAC. Se excluyen ciclos, vecinos caducados y horarios no utilizables. La bajada de métrica del maestro actual puede seleccionar otro vecino conservado. |
| Promoción | MIF + versión + clase de dispositivo preceden a la elección. Un PSF inicial se conserva para completar el vecino, pero no basta para elegirlo. |
| Adopción de horario | Reloj, presencia, duración y secuencia se adoptan juntos. Antes podía cambiarse el reloj aun rechazando los canales de ese mismo vecino. |
| Control de Apple | Los controles individuales se conservan para GET, pero quedan preparados hasta recibir una acción completa; no modifican parcialmente el horario activo. Esto evita que el PHY y la plantilla transmitida anuncien horarios distintos. `AWDL_CONTROL_COMMIT=complete-action-template` expone esta decisión. |
| Plantilla tardía por BPF | Una acción válida de Apple puede sustituir la configuración nativa inicial. Antes solamente se adoptaba si aún no existía ninguna plantilla. |
| Gestión de acciones pendientes | Se limita a una acción pendiente por visita; las acciones AWDL de un horario ya sustituido se descartan. Se reevalúa el tiempo después de transmitir gestión y antes de enviar datos. |
| Recepción y coexistencia STA | Se conserva escucha durante todo EAW no nulo, guardas sólo para TX, vuelta a STA en slots nulos y ante cambio de canal fallido. Se prueban presión de anillo y escaneo. |
| Multicast y unicast | Multicast en slots 0/10; unicast exige vecino válido y coincidencia de canal/ventana. La prueba integrada envía hacia vecino y multicast; una demora de gestión que cruza el EAW impide el envío de datos posterior. |
| Salida BSD → AWDL | El filtro consumía una copia pero dejaba continuar el original, mientras el pull de IO80211 se deshabilitaba. Ahora consume el original y devuelve EJUSTRETURN al capturar; los paquetes no capturados pueden salir por la cola alternativa. |
| Propiedad de mbufs y checksums | 2048 capturas comprobadas con liberación única; se finaliza checksum IPv4/IPv6. Probados cola llena, fallo de duplicación, apagado, horario ausente y trama corta. La salida alternativa también finaliza checksums. |
| Encapsulación y RX | Revisados BSSID AWDL, SNAP Apple, encabezado de datos, QoS/A-MSDU, rechazo de fragmentos/cifrado, CRC/FCS y destino local/multicast. Se conservan las rutas existentes; no se añade cifrado ni reensamblado 802.11. |
| Entrada AWDL → BSD | Se conserva la corrección v17: Ethernet en pkthdr.header, IPv6 al inicio de mbuf_data. Prueba de 206 combinaciones de cabeceras partidas y de errores de propiedad. |
| Radio y ACK | Se mantiene puerto MAC1 para la dirección virtual, sin una segunda STA de firmware. Las pruebas del puerto cubren colisión, rotación de MAC, rollback y preservación de registros STA. Reportes de firmware distinguen envío, ACK y ausencia de ACK. |
| Vecinos IPv6 | Revisados publicación, caché ND6ALT y ausencia; la caducidad de elección se prueba por separado. Publicación en IO80211 y aprendizaje de IPv6 no equivalen a descubrimiento Bonjour. |
| Suspensión y reanudación | Se conservan cancelación del timer, limpieza de colas, retorno a STA e invalidación de sincronización. La prueba integrada verifica que no queden paquetes retenidos tras suspensión/reset. |
| Bonjour y AirDrop | Se incluye consulta explícita por awdl0 y captura opcional de metadatos IPv6. Los tests no ejecutan sharingd, mDNSResponder, negociación TLS ni transferencia AirDrop real. |
| ABI macOS y familias | El proyecto compila contra la ABI privada Ventura de IO80211FamilyLegacy. macOS 26 y el firmware real requieren validación física. Se mantienen RTL8822BE/8822CE/8821CE del proyecto; no se afirma compatibilidad con toda tarjeta existente de rtw88. |

Fuentes concretas para contrastar protocolo: [canales](https://github.com/seemoo-lab/owl/blob/master/src/channel.h), [elección](https://github.com/seemoo-lab/owl/blob/master/src/election.c), [RX](https://github.com/seemoo-lab/owl/blob/master/src/rx.c), [TX](https://github.com/seemoo-lab/owl/blob/master/src/tx.c), [planificación](https://github.com/seemoo-lab/owl/blob/master/src/schedule.c). El contrato de consumo del filtro se verificó en [XNU: kpi_interfacefilter.h](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/net/kpi_interfacefilter.h).

## Límites que siguen abiertos

Los controles privados de Apple no están todos implementados: algunos selectores sólo almacenan valores o devuelven estructuras vacías. Esta revisión no convierte esos puntos en operaciones de firmware ficticias. En particular, si macOS actualiza un horario exclusivamente mediante controles parciales sin proporcionar una nueva acción completa, esos cambios quedan pendientes. Hace falta observar esa secuencia en el sistema real antes de asignar semántica no documentada a sus campos.

No se midió por captura externa el instante real de salida de cada trama, la demora de firmware ni la precisión de retune de cada chip. Las pruebas del scheduler simulan el backend; el ACK físico confirma recepción 802.11, no entrega Bonjour/TCP. No se da por resuelta la detección del iPhone de tu hermana a partir de suposiciones sobre sus MAC.

La suite heredada tampoco está completamente verde. El informe adjunto enumera los 52 fallos que ya existían en la base, incluidos tests con etiquetas antiguas, mocks que ya no compilan y recursos ausentes. No se eliminaron para presentar una aprobación artificial.

## Verificación en el equipo

El ZIP contiene el kext experimental y el diagnóstico. Conserva el kext anterior, sustituye en tu configuración habitual y reinicia. Verifica `DriverBuild = 2.0.1-awdl-integrated-v19` mediante IORegistry; si sigue diciendo v17, no se está probando esta revisión.

1. Un iPhone como receptor con «Todos durante 10 minutos»; Mac como emisor. Repite intercambiando emisor y receptor.
2. Repite con el segundo iPhone, por separado. Prueba primero un archivo pequeño y después uno mayor.
3. Ejecuta `diagnostico-awdl-v19.command` durante el intento. Con privilegios de administrador también registra durante 30 segundos resúmenes de paquetes IPv6 de awdl0; no guarda payloads completos ni cambia ajustes.
4. La validación requiere descubrimiento Bonjour, conexión y transferencia completa en ambas direcciones, con Wi-Fi de infraestructura operativo. Ver sólo el icono por BLE, acciones RX o ACK no basta.

El objetivo de esta entrega es una corrección integrada con trazabilidad, no declarar AirDrop terminado sin esas mediciones.
