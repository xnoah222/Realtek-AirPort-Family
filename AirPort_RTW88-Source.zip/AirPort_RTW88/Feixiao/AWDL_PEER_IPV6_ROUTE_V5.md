# AWDL peer IPv6 route v5

This build keeps the v4 stable-core/sync-peer-sequence radio behavior unchanged.

The only functional change is in the AWDL RX/control bridge: when a real IPv6
Ethernet frame is received on the AWDL data path, the driver learns the exact
source IPv6 address and republishes that MAC<->IPv6 mapping to
IO80211P2PInterface::postPeerPresenceIPv6(). This gives macOS native AWDL peer
management an authoritative neighbor mapping instead of relying only on the
EUI-64 address inferred from action-frame MACs.

Motivation: sharingd/Network.framework resolved remote AirDrop Bonjour services
on awdl0 but repeatedly failed the IPv6 child path with `No network route`,
while raw AWDL TX/RX and Bonjour discovery were already working.

No changes are made to PCI, firmware, interrupts, normal Wi-Fi, en0 association,
scan, power management, rtw88 core, channel scheduling, or AWDL TX framing.

New telemetry:
- AWDL_PEER_IPV6_LEARNED_FROM_DATA
- AWDL_PEER_IPV6_LEARNED_POSTS
- AWDL_PEER_IPV6_LEARNED_MAC
- AWDL_PEER_IPV6_LEARNED_ADDR
