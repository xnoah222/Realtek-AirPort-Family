# AWDL TX report key v15

V14 proved that RTL8822B firmware C2H TX reports arrive, but every report was cached early and none was consumed at PCI completion. The requested and firmware sequence numbers matched in aggregate, so the remaining weak link was the PCI completion copy of the report sequence stored inside `ieee80211_tx_info::status_driver_data`.

V15 preserves the firmware TX-report sequence in a dedicated field of the macOS `sk_buff` shim at descriptor submission time. PCI completion uses that stable field as the report key and retains the legacy `rtw_pci_tx_data::sn` only as a diagnostic comparison.

New telemetry:
- `RTW88_TXR_PCI_SN_MISMATCH`
- `RTW88_TXR_LAST_PCI_SN`
- `RTW88_TXR_LAST_PCI_LEGACY_SN`

No AWDL scheduler, channel, TSF, ND6ALT, RX, association, or normal Wi-Fi policy is changed.
