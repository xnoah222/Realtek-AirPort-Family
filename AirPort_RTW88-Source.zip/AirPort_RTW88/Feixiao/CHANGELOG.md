# 2.0.1 — stable-core AWDL surgical rebuild

- Rebased AWDL work on the known-good Realtek AirPort Family AirPort_RTW88 source instead of the experimental multi-VIF branch.
- Keeps the PCI/IRQ/firmware/scan/association/power-management/rtw88 core unchanged from the stable baseline.
- AWDL is subordinate to en0: the scheduler stays suspended until the primary IO80211 enable path succeeds and is stopped before en0 is disabled.
- Replaces the unreliable private IO80211 AWDL data dequeue as the primary outbound path with an awdl0-only interface-filter KPI observer.
- The interface filter duplicates fully formed awdl0 Ethernet packets and feeds only the duplicate to the AWDL scheduler; the original BSD/IO80211 packet lifecycle is left untouched.
- RX AWDL Ethernet data is delivered through the published awdl0 ifnet rather than a guessed private IO80211 packet-info ABI.
- IO80211 owns peer publication; direct private postPeerPresence/postPeerPresenceIPv6/postPeerAbsence calls were removed.
- Retains the newer AWDL parser/scheduler fixes: validated peer lifecycle, Apple sync-channel sequence parsing, 6/44/149 social discovery, multicast rendezvous, channel restoration, and bounded telemetry.
- No second rtw88 hardware VIF is created for AWDL.

# 2.0.0

- Reworked AWDL around an AirportItlwm-style IO80211 control plane plus an OpenAWDL-derived over-air scheduler.
- IO80211 sync templates, channel hints, sync parameters, presence/election state are now treated as authoritative policy; the Realtek backend owns only safe PHY/channel execution.
- Added a 1.5 s IO80211 grace period before native/OpenAWDL bootstrap, with immediate takeover when an Apple sync template appears.
- AWDL BPF management/action frames are now queued and transmitted only inside an owned AWDL availability window instead of being injected immediately on the infrastructure channel.
- A valid Apple AWDL BPF action can seed the runtime sync template when Ventura supplies it through BPF before the dedicated template selector.
- AWDL channel/master/sequence IOCTLs no longer retune the single RTL88 PHY directly; the STA/AWDL timeslicer performs all physical channel changes.
- Added IORegistry telemetry for control-plane ownership and Apple action-frame queue/TX state.
- Added `tests/test_v200_awdl_airportitlwm_bridge.py`.
- Added explicit IONetworkController/IOKit power-management registration.
- Added hibernation-safe cold reinitialization of the RTL88 PCI function.
- Quiesce order: AWDL -> scan/auth -> rtw88 core -> IRQ/DMA -> PCI memory.
- Resume order: PCI memory/bus master -> rtw88 core/firmware -> IRQ -> AWDL discovery.
- Never resurrect stale pre-hibernate association/key state.
- Added PM telemetry and regression test `tests/test_v200_hibernation.py`.
- Preserves v53-v57 datapath/AWDL work.

# Changelog

## 1.0.1

- Expanded PCIe device-ID coverage across the supported RTL88xx family mappings.
- Added/updated embedded firmware coverage for the enabled PCIe chipsets.
- Fixed overlapping CoreWiFi scans by coalescing requests instead of returning busy/error 16.
- Corrected the bundled Ventura `apple80211_scan_result` ABI to match the layout expected by airportd.
- Retains the stable native AirPort/IO80211 STA path from 1.0.0.
- Retains CURRENT_NETWORK / Location Services compatibility work from the late 1.0.0 development branch.
- AWDL/P2P code remains experimental and is not a supported 1.0.1 feature.

### Hardware validation

RTL8822BE is the physically validated adapter. Other enabled PCIe IDs remain experimental until confirmed on real hardware.
