# AWDL discovery RX v16 — experimental

Esta revisión parte del ZIP `AirPort_RTW88-Source-2.0.1-AWDL-tx-report-key-v15.zip`.
Identificador observable: `DriverBuild = 2.0.1-awdl-discovery-rx-v16`.

## Qué cambia

- El planificador escucha durante toda ventana EAW anunciada con un canal concreto, incluso antes de descubrir vecinos y cuando macOS proporciona el horario. Anteriormente, sin tráfico o vecino promovido, regresaba al AP después de la ventana común de 16 TU, aunque anunciaba una EAW de 64 TU. Eso impedía recibir anuncios y respuestas durante buena parte de la disponibilidad publicada.
- Las guardas y la falta de espacio en la cola TX impiden transmitir, pero ya no cancelan la recepción. Los intervalos sin canal y los fallos de sintonización devuelven la radio a la infraestructura.
- Se reserva el puerto MAC 1 para la dirección AWDL y su BSSID. El modo promiscuo por sí solo no programa esa dirección como receptora local. Se usan los registros comunes existentes de rtw88, sin crear una segunda estación de firmware ni cambiar la MAC del puerto principal.
- Se comprueba la escritura de MAC/BSSID, se rechazan colisiones de puerto, se limpia el estado tras un error y se libera el puerto antes de apagar la radio. Al reactivarla se programa de nuevo. Un fallo del puerto AWDL no apaga el Wi-Fi principal.
- Nuevos diagnósticos: `AWDL_RX_HW_PORT`, `AWDL_RX_HW_PORT_RESULT`, `AWDL_RX_HW_PORT_PROGRAMMED` y `AWDL_ADVERTISED_EAW_RX`.

`AWDL_RX_HW_PORT_PROGRAMMED=Yes` confirma lectura de registros; **no demuestra ACKs reales por radio**. Las confirmaciones del otro equipo siguen visibles mediante los contadores TX report de v15.

## Evidencia disponible

La lectura del equipo durante esta sesión mostró macOS 26.7.1 y un controlador cargado **2.0.0-awdl-peer-lifecycle-sta-recovery**, anterior al ZIP recibido. `awdl0` estaba activa; los contadores acumulados mostraban 29 anuncios recibidos, 29 MIF, 1 paquete de datos transmitido, 0 datos recibidos y 0 vecinos válidos en esa captura. Son contadores de la compilación antigua, no resultados de v16.

El último canal siguiente publicado era 100. El código conserva las restricciones para canales deshabilitados, NO_IR y DFS/RADAR; no se habilita transmisión arbitraria sobre esos canales. Para una primera comparación controlada conviene usar un AP en un canal permitido por ambas tarjetas, por ejemplo 6 o 44, y registrar también el comportamiento sin conexión al AP.

## Alcance y límites

El Makefile sigue compilando RTL8822BE, RTL8822CE y RTL8821CE, las variantes PCIe habilitadas por este proyecto. El cambio es común a ellas; no se ha probado cada tarjeta físicamente ni se añade soporte a todas las variantes USB/SDIO del árbol Linux.

Se conserva la integración IO80211 de Ventura y la dependencia IO80211FamilyLegacy existente. Compilar en macOS 26 no verifica por sí solo la compatibilidad de todas sus interfaces privadas.

**AirDrop bidireccional, Continuity Camera e Instant Hotspot todavía no están confirmados con este binario.** Esta revisión corrige defectos del transporte/descubrimiento AWDL; no constituye una implementación completa validada de todos los servicios Continuity. La tasa TX conservadora de 6 Mbps y el ritmo de un paquete por tick permanecen, por lo que tampoco se garantiza rendimiento de vídeo.

La recepción ocupa ahora toda la disponibilidad publicada: aproximadamente 25% del ciclo en el horario nativo disperso, y potencialmente más al adoptar un horario de vecino. Hay que comprobar latencia y estabilidad del Wi-Fi principal.

## Validación realizada

- `make -j4 airport`: compilación y enlace x86_64 correctos para los tres chipsets habilitados. Persisten advertencias del árbol original.
- Plist válido y símbolo `rtw88_awdl_rx_port` resuelto dentro del binario.
- Dos pruebas nuevas ejecutan el planificador de producción con radio/IOKit simulados y las funciones reales de configuración de puerto con MMIO simulado. Cubren descubrimiento sin vecinos, horarios Apple/nativo, guardas, cola TX ocupada, retorno al AP, canales no soportados, multicast, promoción de vecino, unicast, escaneo, liberación, colisiones, rotación de MAC y rollback tras errores.
- Comparación de la suite completa: original 55/107 aprobadas; v16 57/109 aprobadas; ninguna prueba previamente aprobada deja de aprobarse. Permanecen 52 fallos preexistentes. No se declara la suite completamente aprobada.
- Se usó UndefinedBehaviorSanitizer. AddressSanitizer compiló, pero su runtime terminó con SIGILL incluso con `int main(){return 0;}` en este host; por ello no se declara una ejecución ASan satisfactoria. Para comparar las suites se adaptó explícitamente `-fsanitize=address,undefined` a `-fsanitize=undefined` y se indicó la ruta libc++ del SDK.

Pruebas nuevas reproducibles desde `Feixiao`:

```sh
RTW88_TEST_SANITIZERS=undefined python3 tests/test_v209_awdl_discovery_rx.py
RTW88_TEST_SANITIZERS=undefined python3 tests/test_v210_awdl_rx_port.py
make -j4 airport
```

En un host con ASan operativo, omitir `RTW88_TEST_SANITIZERS` ejecuta ambas con ASan+UBSan.

## Cómo comprobar el binario

1. Conserva una copia del kext que actualmente arranca. Sustituye la entrada existente de `AirPort_RTW88.kext` en tu EFI por el kext del paquete; conserva sus dependencias y evita cargar dos copias. Esta sesión no modifica la EFI ni instala el kext.
2. Reinicia y comprueba que `DriverBuild` contiene `2.0.1-awdl-discovery-rx-v16`:

   ```sh
   ioreg -r -c AirportRTW88 -l | grep DriverBuild
   ```

3. Abre AirDrop en ambos dispositivos y habilita temporalmente recepción de todos para descartar filtros de contactos. Comprueba primero que se detectan; luego envía un archivo pequeño Mac → iPhone y otro iPhone → Mac. Repite con un archivo mayor y observa el Wi-Fi principal.
4. Ejecuta `diagnostico-awdl-v16.command` durante las pruebas. Genera dos capturas separadas por 30 segundos, vecinos IPv6, contadores, versiones cargadas, exploración Bonjour y eventos de `sharingd`/driver. No modifica ajustes ni carga controladores. La exploración Bonjour es auxiliar: que no liste un servicio no demuestra por sí solo fallo AWDL.
5. Comprueba `AWDL_RX_HW_PORT=1`, resultado 0, incremento de `AWDL_ACTION_RX`, vecinos válidos, `AWDL_DATA_RX`, TX y ACKs. Si se programa el puerto pero no llegan datos, hacen falta esos registros y posiblemente una captura 802.11 desde otro adaptador para verificar ACKs y sincronización por radio.
6. Tras AirDrop, prueba suspensión/reactivación, reconexión Wi-Fi y después Continuity Camera e Instant Hotspot por separado. Mantén diferenciados los resultados de cada servicio.

## Referencias

- [OWL, implementación pública de AWDL](https://github.com/seemoo-lab/owl): sincronización, ventanas y distinción entre recepción y ACKs en monitor activo. Se consultó como referencia; esta revisión no incorpora código nuevo copiado de OWL.
- [Requisitos de Continuity de Apple](https://support.apple.com/en-ca/108046).
