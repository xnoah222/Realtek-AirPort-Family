# AWDL TX Report Race v14

v13 proved a deterministic ordering race in the macOS port: the firmware C2H
TX report arrives before PCI TX completion puts the skb into `tx_report.queue`.

Evidence from v13:
- requested = 6
- descriptor enabled = 6
- PCI enqueued = 6
- C2H seen = 6
- C2H unmatched = 6
- purged = 6
- last requested SN == last C2H SN

v14 makes report matching order-independent. If C2H arrives first, its status is
cached for at most `RTW_TX_PROBE_TIMEOUT` using the Realtek 6-bit report sequence
index. PCI completion consumes that cached status and calls the normal
`ieee80211_tx_status_irqsafe()` path.

No AWDL scheduling, TSF, channel, RX, ND6ALT, STA association, firmware, normal
Wi-Fi datapath, or power policy is changed.

Telemetry:
- RTW88_TXR_EARLY_C2H_CACHED
- RTW88_TXR_EARLY_C2H_CONSUMED
- RTW88_TXR_EARLY_C2H_EXPIRED
