# AWDL surgical rebuild — validation notes

Validation performed before packaging this source:

- All six C++ translation units used by the `airport` target pass Clang syntax compilation for `x86_64-apple-darwin22` with the bundled MacKernelSDK headers.
- `kmod_info.c` passes target syntax compilation with AirPort kmod metadata enabled.
- `tests/test_v201_awdl_surgical_sta_safe.py`: 13/13 invariants pass.
- `make -n airport` reaches the normal AirPort object/link/package plan.
- `AirportRTW88AWDL.cpp` was compiled as a Mach-O x86_64 object and its undefined-symbol footprint was compared with the stable baseline.
  - Stable AWDL bridge: 49 unique undefined symbols.
  - Surgical AWDL bridge: 57 unique undefined symbols.
  - The only `IO80211P2PInterface` undefined symbol remains the same constructor dependency already present in the stable source; this rebuild does **not** create a derived P2P-interface vtable.
  - New external dependencies are networking KPIs used by the awdl0-only interface filter / mbuf clone path (`iflt_*`, `ifnet_*`, `mbuf_*`) plus project-internal manager symbols.
- A recursive source-tree comparison confirms no modifications under `rtw88-stable/`, `Feixiao/src/compat/`, MacKernelSDK, RTW88PCIDevice, or the Makefile.

Limitations of this validation environment:

- It does not contain macOS `xcrun`, so the final kext link/codesign step cannot be executed here.
- It cannot validate RF timing or Apple-to-Realtek AWDL interoperability. Those require booting the built kext on the target Mac and completing a real AirDrop/data test.

## Peer publication v2 runtime-directed repair
- Runtime evidence: 3 validated AWDL peers, 55/55 data TX successes, 3 data RX frames, but zero IO80211 peer-publish counters and no inbound peer visibility in AirDrop.
- Restored the stable Realtek-AirPort-Family validated/throttled `postPeerPresence` + IPv6 presence lifecycle and stale `postPeerAbsence` notifications.
- Private presence return values remain intentionally ignored; they cannot influence radio or en0 state.
- Added bounded last-RX Ethernet header/EtherType telemetry.
- `test_v201_awdl_surgical_sta_safe.py`: 13/13.
- `test_v202_awdl_peer_publication_safe.py`: 9/9.
- All six AirPort C++ translation units pass Clang syntax validation for x86_64 Darwin; `kmod_info.c` also passes.
