# AWDL ND6ALT bootstrap v7

The v6 runtime test showed that XNU had no native node-presence entries because the native ND6ALT notification was only issued after an inbound AWDL DATA frame. That is too late for the first unicast AirDrop connection.

v7 additionally publishes a validated control-plane peer to `ifnet_notice_node_presence_v2()` using its AWDL MAC-derived RFC4291 link-local IPv6 address. This bootstraps XNU's alternate AWDL/NAN neighbor cache before any unicast DATA exchange. The v6 DATA-RX refresh remains and refreshes the mapping with the exact IPv6 source observed on real traffic.

No rtw88 core, PCI, firmware, scan, association, power-management, normal Wi-Fi TX/RX, or channel-scheduler code is changed.
