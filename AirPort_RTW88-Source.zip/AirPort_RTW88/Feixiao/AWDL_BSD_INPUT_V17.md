# AWDL BSD input v17 — experimental

## Diagnóstico de v16 cargada

Esta sesión verificó `DriverBuild=2.0.1-awdl-discovery-rx-v16` en el equipo. La captura mostraba:

- `awdl0` activa; puerto MAC AWDL 1 programado sin error.
- 1208 anuncios AWDL recibidos; un vecino válido en la captura.
- 191 paquetes de datos recibidos y 117 transmitidos.
- 53 unicast con ACK, 0 sin ACK, 0 informes pendientes.
- Vecinos IPv6 presentes en `awdl0`.

Estos valores demuestran actividad bidireccional del transporte, pero no éxito de AirDrop. `ifnet_input=0` tampoco demuestra que IPv6 o Bonjour hayan aceptado los paquetes: la entrega posterior puede descartarlos.

## Fallo corregido

La ruta directa a `ifnet_input` conservaba los 14 bytes Ethernet al inicio de `mbuf_data` y en la longitud del paquete. DLIL obtiene la cabecera de enlace mediante `pkthdr.header`, mientras IPv6 espera empezar directamente en sus propios datos. El paquete multicast observado empezaba por `33:33`, que no puede interpretarse como la versión IPv6.

La v17 conserva la cabecera Ethernet en memoria y su puntero, desplaza el inicio de datos 14 bytes y ajusta ambas longitudes antes de llamar a `ifnet_input`. También reagrupa cabeceras fragmentadas, mantiene la propiedad del paquete en las rutas de error y proporciona los incrementos de estadísticas RX de la interfaz.

El comportamiento se contrastó con [IONetworkInterface::inputPacket de Apple](https://github.com/apple-oss-distributions/IONetworkingFamily/blob/main/IONetworkInterface.cpp) y con [ether_demux de XNU](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/net/ether_if_module.c). No se sustituyen interfaces privadas ni se copia una implementación ajena.

La configuración del puerto MAC, el planificador y los límites regulatorios de v16 permanecen. Los rechazos ocasionales `master-mismatch` observados no se alteran en esta revisión; podrían requerir investigación adicional si persisten problemas después de corregir la entrega IPv6.

## Validación

- Compilación y enlace del kext x86_64 correctos.
- Nueva prueba sobre la función de producción: 206 entregas L2/L3, destinos multicast/unicast, todos los cortes de cabecera entre bloques, estadísticas y errores de memoria/KPI. Ejecutada con UBSan.
- Las pruebas de planificación y de programación del puerto de v16 siguen aprobando.
- La comparación de la suite completa y sus fallos heredados figuran en `PRUEBAS-AWDL-v17.md`.
- ASan no se declara validado: su runtime falla con SIGILL en este host incluso en un programa vacío. La comparación usa UBSan y las cabeceras libc++ del SDK, como en v16.

Desde `Feixiao`:

```sh
RTW88_TEST_SANITIZERS=undefined python3 tests/test_v211_awdl_bsd_input.py
RTW88_TEST_SANITIZERS=undefined python3 tests/test_v209_awdl_discovery_rx.py
RTW88_TEST_SANITIZERS=undefined python3 tests/test_v210_awdl_rx_port.py
make -j4 airport
```

## Prueba en el equipo

1. Sustituye el kext v16 de la entrada existente en tu EFI por el del paquete v17, conservando una copia del anterior y las dependencias existentes. Reinicia. Esta sesión no instala ni carga el binario nuevo.
2. Comprueba la compilación activa:

   ```sh
   ioreg -r -c AirportRTW88 -l | grep DriverBuild
   ```

   Debe mostrar `2.0.1-awdl-bsd-input-v17`.

3. Abre AirDrop en ambos equipos, con recepción de todos temporalmente, e intenta descubrir y enviar un archivo pequeño en cada dirección.
4. Ejecuta el `diagnostico-awdl-v17.command` incluido durante esos intentos. Tras recibir tráfico, la propiedad `AWDL_RX_DELIVERY_PATH` debe ser `ifnet_input-l3-with-l2-header`. El script genera dos capturas separadas por 30 segundos y datos auxiliares de Bonjour, vecinos y estadísticas. Los permisos del sistema pueden impedir la lectura de algunos logs; conserva igualmente las demás capturas.
5. Si aparece el dispositivo pero la transferencia falla, conserva el resultado concreto de cada dirección. Si continúa sin aparecer, los contadores y las nuevas estadísticas permiten continuar separando transporte, entrega IPv6 y descubrimiento de servicio.

**AirDrop, Continuity Camera e Instant Hotspot aún requieren validación funcional con v17.** Esta revisión elimina un defecto de formato en la entrega a IPv6; no se presenta como confirmación de interoperabilidad completa.

Se mantienen los chipsets del proyecto: RTL8822BE, RTL8822CE y RTL8821CE; no se declara prueba física en los tres.
