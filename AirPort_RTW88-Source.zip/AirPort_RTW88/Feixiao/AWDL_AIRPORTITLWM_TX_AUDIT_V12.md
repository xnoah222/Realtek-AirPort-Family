# AWDL AirportItlwm / rtw88 TX audit — v12

Baseline: `2.0.1-awdl-tsf-sync-v11`.

## AirportItlwm comparison

AirportItlwm is useful as an IO80211 ABI/control-plane reference, not as an
on-air AWDL datapath reference. Its current `AirportVirtualIOCTL.cpp` exposes
the expected AWDL selectors and its VIF lifecycle calls the superclass before
`setEnabledBySystem(true)`, link-up and `APPLE80211_M_LINK_CHANGED`. v11 is
already aligned with that shape.

Crucially, current AirportItlwm does **not** implement AWDL transport: its
`outputActionFrame()` and `bpfOutput80211Radio()` consume/free the mbuf, and
the AWDL branch of `requestPacketTx()` has the dequeue/output body commented
out. Copying those paths cannot make AirDrop bidirectional.

The selectors present in AirportItlwm but not mirrored literally by v11 are
`RATE`, `ROAM_PROFILE`, and `IE`, plus a newer `AWDL_CAPABILITIES` selector in
its current headers. None was observed as an unsupported request on the tested
Ventura session, so v12 deliberately does not mix speculative ABI changes into
the radio diagnosis.

## Actual Realtek TX path

rtw88 already provides a firmware-backed TX report mechanism. Setting
`IEEE80211_TX_CTL_REQ_TX_STATUS` makes PCI completion retain the skb in the
`tx_report` queue; a later CCX firmware report calls mac80211 TX status with
`IEEE80211_TX_STAT_ACK` only when the peer acknowledged the 802.11 frame.
Without that flag, PCI completion marks ordinary unicast as ACKed
unconditionally, so previous `AWDL_DATA_TX` counters proved DMA submission
only.

v12 requests reports only for AWDL **unicast**. Multicast keeps NO_ACK and is
not placed in the firmware-report queue. `RTW88IEEE80211::txStatus()` filters
for the AWDL BSSID/source identity and exports ACK/no-ACK telemetry via the
AWDL manager. No scheduler, TSF, channel, peer, ND6ALT, normal STA TX, PCI or
firmware policy was changed.

## New telemetry

- `AWDL_TX_UNICAST_SUBMITTED`
- `AWDL_TX_MULTICAST_SUBMITTED`
- `AWDL_TX_STATUS_REQUESTED`
- `AWDL_TX_STATUS_COMPLETED`
- `AWDL_TX_STATUS_ACKED`
- `AWDL_TX_STATUS_NOACK`
- `AWDL_TX_STATUS_OUTSTANDING` (requested minus completed; after the firmware
  report timeout window, a persistent value means reports were lost/purged)
- `AWDL_TX_STATUS_LAST_DST`
- `AWDL_TX_STATUS_LAST_ACKED`

Interpretation: many completed+ACKED proves Mac -> peer physical unicast works;
completed+NOACK proves the peer is not ACKing our raw frames; requested with no
completed and growing outstanding points to a broken/missing RTL firmware TX
report path rather than proof either way.
