# AWDL surgical padding v3

This build keeps the v2 stable-core / peer-publication architecture unchanged.

The only functional change is in the AWDL action-frame parser: 1-2 trailing zero
alignment bytes after the final TLV are accepted instead of being interpreted as
an incomplete TLV header. Non-zero trailing bytes still fail parsing.

Why: runtime telemetry from a real RTL8822BE showed many otherwise valid Apple
AWDL action frames rejected as `trailing-tlv-header`; sparse MIF reception can
make peer availability/channel state stale even while Version frames continue
to arrive.

This change does not touch PCI, IRQ, Wi-Fi association, scan, power management,
normal en0 TX/RX, channel switching, AWDL peer publication, or AWDL data framing.
