# AWDL native ND6ALT peer cache v6

This revision keeps the v4/v5 radio and data path unchanged and fixes the IPv6
neighbor integration expected by macOS AWDL interfaces.

XNU marks AWDL interfaces for alternate IPv6 neighbor management (ND6ALT), so
normal Neighbor Solicitation/Advertisement is not used.  On inbound AWDL IPv6
data, the driver now reports the observed IPv6 + Ethernet peer pair through the
public `ifnet_notice_node_presence_v2()` KPI.  That KPI is the supported bridge
into XNU's alternate neighbor cache and node-presence events.

The existing IO80211 peer publication is retained for IO80211/wifip2pd state.
No PCI, firmware, STA association, scan, IRQ, power-management, or normal en0
paths are changed.

Telemetry:
- `AWDL_NATIVE_NODE_PRESENCE_RESULT`
- `AWDL_NATIVE_NODE_PRESENCE_OK`
- `AWDL_NATIVE_NODE_PRESENCE_POSTS`
- `AWDL_NATIVE_NODE_PRESENCE_MAC`
- `AWDL_NATIVE_NODE_PRESENCE_ADDR`
